/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package passwordverifierexam;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;


public class PasswordVerifierExam {
    private String password;
    private String userName;
    
    public PasswordVerifierExam(String password, String userName){
    this.password = password;
    this.userName = userName;
    }
    private boolean hasOneDigit(){
    int count = 0;
    for(int i = 0; i < password.length(); i++){
    if(password.matches(".*\\d*")){
    count++; 
    }
    }
    return count >=1;
    }
    public boolean isValid(){
    
    int length = password.length();
    int lowerCase = 0, upperCase = 0,lengthValue = 0;
    for (int i = 0; i< password.length(); i++){
    if(Character.isLowerCase(password.charAt(i))){
    lowerCase++;
    }
    if(Character.isUpperCase(password.charAt(i))){
    upperCase++;
    }
    if(length >= 6){
    lengthValue = 1;
    }
    }
    
    return hasOneDigit() && lowerCase >= 1 && upperCase >= 1 && lengthValue >= 1;
    }
    
public void WriteToFile(String userName, String password) throws IOException{
FileWriter write = new FileWriter("users.txt");
write.write("Username: " + userName);
write.write("\nPassword:" + password);
write.close();

}
    
    
    
    public static void main(String[] args) throws IOException {
        Scanner input = new Scanner(System.in);
        System.out.println("Please Insert your Username: ");
        String userName = input.nextLine();
        System.out.println("Please Insert your password: ");
        String password = input.nextLine();
        PasswordVerifierExam pw = new PasswordVerifierExam(password, userName);
        
        
        
  if(pw.isValid() == false){
      for(int i = 0; i < 3; i++){
  System.out.println("The password you have choosen does not match the criteria"+
          " please try again!");
password = input.nextLine();
if(i == 2){
System.out.println("Shutting down system, too many incorrect passwords");
System.exit(0);
}
  }
  }else if(pw.isValid() == true){
  System.out.println("Your Password is Valid! Saving Data");
  pw.WriteToFile(userName,password);
  
  
  }
    
    
    
    }      
  
    
}
