/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wordcounterexam;

import java.util.Scanner;


public class WordCounterExam {


    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       System.out.println("Please type in the content you wish to check");
      String str = input.nextLine();
      System.out.println("There is a total of " +getWordCount(str) + " words in the previous sentence?");
    }
    
    public static int getWordCount(String str){
     String[] split = str.split(" ");
    return split.length;
    }
    
    
    
    
    
    
    
    
    
}
