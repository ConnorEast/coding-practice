/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package piglatinexam;

import java.util.Scanner;

public class PigLatinExam {

    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Please type a sentence you would like translated to" +
            " pigLatin");
    String wordList = input.nextLine();
    String[] wordArray = wordList.split(" ");
    
    String result = "";
    
   for(int i = 0; i < wordArray.length; i++ ){
   if(i == 0){
   result += wordArray[i] + "AY ";
   } else {
   char ch = wordArray[i].charAt(0);
   result += wordArray[i].substring(1) + "" + ch + "AY ";
   }
   }
   System.out.println("English Statement:\t" + wordList
   +"\nPig-Latin Translation: " + result);
   
   
   
    }
    
}
