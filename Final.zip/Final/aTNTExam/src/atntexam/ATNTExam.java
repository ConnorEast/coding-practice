  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atntexam;

import java.util.Scanner;


public class ATNTExam {

 
    public static void main(String[] args) {
        
        String[][] nums ={
            {"2", "A","B","C"},
            {"3", "D","E","F"},
            {"4", "G","H","I"},
            {"5", "J","K","L"},
            {"6", "M","N","O"},
            {"7", "P","Q","R"},
            {"8", "T","U","V"},
            {"9", "W","X","Y"},
        };

        Scanner input = new Scanner(System.in);
        System.out.println("Please type in your 10 digit Alpha-numeric number:");
        String phoneNumber = input.nextLine();
        if(phoneNumber.length() > 12){
        System.out.println("this number is invalid, Please try again:");
        phoneNumber = input.nextLine();
        }
        char[] arrayContent = phoneNumber.toCharArray();
        for(int i = 0; i < arrayContent.length; i++){
            if(Character.isLetter(arrayContent[i])){
            
                if(arrayContent[i] == 'A' || arrayContent[i] == 'B' || arrayContent[i] == 'C'){
                    arrayContent[i] = '2';
                }
                else if(arrayContent[i] == 'D' || arrayContent[i] == 'E' || arrayContent[i] == 'F'){
                    arrayContent[i] = '3';
                } 
                else if(arrayContent[i] == 'G' || arrayContent[i] == 'H' || arrayContent[i] == 'I'){
                    arrayContent[i] = '4';
                }
                    if(arrayContent[i] == 'J' || arrayContent[i] == 'K' || arrayContent[i] == 'L'){
                    arrayContent[i] = '5';
                }
                else if(arrayContent[i] == 'M' || arrayContent[i] == 'N' || arrayContent[i] == 'O'){
                    arrayContent[i] = '6';
                } 
                else if(arrayContent[i] == 'P' || arrayContent[i] == 'Q' || arrayContent[i] == 'R' || arrayContent[i] == 'S'){
                    arrayContent[i] = '7';
                }
                else if(arrayContent[i] == 'T' || arrayContent[i] == 'U' || arrayContent[i] == 'V'){
                    arrayContent[i] = '8';
                } 
                else if(arrayContent[i] == 'W' || arrayContent[i] == 'X' || arrayContent[i] == 'Y' || arrayContent[i] == 'Z'){
                    arrayContent[i] = '9';
                }
            }
        
        }
        System.out.print("Your number translates too: ");
        for (char ch: arrayContent){
        System.out.print(ch);
        }
        
        
        
        
    }
    
}
