/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vowelsandconsonantsexam;
import java.util.Scanner;

public class VowelsAndConsonantsExam {

public String words;

public VowelsAndConsonantsExam(String str){
this.words = str;

}

public int getVowels(){
    int countvowels = 0;
    for(int i = 0; i < words.length(); i++){
    boolean checkvow = (words.charAt(i)== 'a' || words.charAt(i)== 'e' || 
            words.charAt(i)== 'i' || words.charAt(i)== 'o' || 
            words.charAt(i)== 'u');
 if(checkvow){
 countvowels++;}
    }
    
   
    return countvowels;
    }


public int getCons(){
    int count = 0;
    for (int i = 0; i< words.length(); i++){
    boolean check = !(words.charAt(i)== 'a' || words.charAt(i)== 'e' || 
            words.charAt(i)== 'i' || words.charAt(i)== 'o' || 
            words.charAt(i)== 'u' || words.charAt(i)== ' ');

    if(check){
    count++;
    }

    }

    return count;
    }






    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    System.out.println("Please enter a string: ");
    String str = input.nextLine();
    while (str.isEmpty()){
    System.out.print("Apologies but, if you input nothing nothing will show up"+
            "... Please try again: ");
    str = input.nextLine();
    }
    char option = ' '; 
    VowelsAndConsonantsExam vc = new VowelsAndConsonantsExam(str);
    do{
    System.out.println("\n\nChoose a letter from the menu." +
            "\n\n\ta. Count the number of vowels." +
            "\n\tb. Count the number of consonants."+
            "\n\tc. Count both the vowels and consonants in string." +
            "\n\td. Enter Another String."+
            "\n\te. Exit Program");
    
    System.out.print("\n\tYour Oprion: ");
            option = input.nextLine().charAt(0);
            
    switch(option){
        case 'a':
        System.out.println("there are '" + vc.getVowels() + "' Vowels in ( "
                + str +" )" );
    break;
        case 'b':
    System.out.println("there are '" + vc.getCons() + "' Consonants in ( "
            + str +" )" );
    break;
            case 'c':
    System.out.println("there are '" + vc.getVowels() + "' Vowels and '"+ 
            vc.getCons()+"' Consonants in ( " + str +" )" );
    break;
            case 'd':
     System.out.println("Please enter a new string: ");
     str = input.nextLine();
    break;
            case 'e':
                System.exit(0);
                break;
                
                
            default: System.out.println("You did not enter a valid input.");
    }
            
            
            
            
    
    }while(option != 'e');


    }
    
}
