/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumofnumbersexam;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author givem
 */
public class SumOfNumbersExam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please Enter a series of numbers seperated"
                +" by commas: ");
        String nmbrArray = input.nextLine();
        String[] strNumbers = nmbrArray.split(",");
        int sum = 0;
     for(String strnum : strNumbers){
     sum += Integer.parseInt(strnum);
     }
        System.out.println("\nThe sum of all inputed values is" + sum);
        
        
        
        
        
        
        
        
        
        
    }
    
}
