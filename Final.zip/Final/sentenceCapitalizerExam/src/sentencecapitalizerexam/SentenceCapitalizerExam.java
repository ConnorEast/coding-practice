/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sentencecapitalizerexam;
import java.util.Scanner;
public class SentenceCapitalizerExam {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please type a sentence you would like Capatalized: ");
        String str = input.nextLine();
                capitalize( str);
    }
    
    public static void capitalize(String str){
    String[] split = str.split("\\.");
    for(String sentence : split){
    System.out.print(sentence.substring(0,1).toUpperCase() + sentence.substring(1));
    }
    
    }
}
