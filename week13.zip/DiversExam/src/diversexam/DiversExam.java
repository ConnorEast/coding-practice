/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diversexam;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author givem
 */
public class DiversExam {
private String[] answerKey = {
"B","D","A","A","C","A","B","A","C","D","B","C","D","A","D","C","C","B","D","A"
};
private String[] studentAnswers = new String[20];

public DiversExam(String[] studentAnswer){
this.studentAnswers = studentAnswer;
}
public boolean passed(){
int count = 0;
for(int i = 0; i < answerKey.length; i++){
if(answerKey[i].equals(studentAnswers[i])){
count++;
}
}
return count >= 15;
}

public int getCorrectAnswers(){
int count = 0;
for(int i =0; i < answerKey.length; i++){
if(answerKey[i].equalsIgnoreCase(studentAnswers[i])){
count++;
}
}
return count;
}
public int getIncorrectAnswers(){
int count = 0;
for(int i =0; i < answerKey.length; i++){
if(!(answerKey[i].equalsIgnoreCase(studentAnswers[i]))){
count++;
}
}
return count;
}
public ArrayList<Integer> getQuestionsMissed(){
ArrayList<Integer> missed = new ArrayList<>();
for (int i = 0; i < studentAnswers.length; i++){
if(studentAnswers[i].isEmpty()){
missed.add(i+1);
}
}
return missed;

}




    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] studentAnswers = new String[20];
        for(int i = 0; i < studentAnswers.length; i++){
        System.out.println("Enter your Answer" + (i+1) +":");
        String answer = input.nextLine();
        while (!validAnswer(answer)){
        System.out.println("Apologies, you may only answer A, B, C, or D. If you would like to skip this question press enter");
           answer = input.nextLine();
        }
        studentAnswers[i] = answer;
        }
        System.out.println("");
        DiversExam exam = new DiversExam(studentAnswers);
       
        if(exam.passed()){
        System.out.println("Congratulations, you have passed this test!");
        } else {
                System.out.println("you failed. Better luck next time!");
                }
        System.out.println("");
System.out.println("Correct Answers: " + exam.getCorrectAnswers()
+"\nIncorrect Answers:" + exam.getIncorrectAnswers()
+"\nMissed Questions" + exam.getQuestionsMissed());
        
        
        
    }
    public static boolean validAnswer(String answer){
    return answer.equalsIgnoreCase("A") || answer.equalsIgnoreCase("B") || 
            answer.equalsIgnoreCase("C") || answer.equalsIgnoreCase("D") ||
            answer.isEmpty();
    }}
    

